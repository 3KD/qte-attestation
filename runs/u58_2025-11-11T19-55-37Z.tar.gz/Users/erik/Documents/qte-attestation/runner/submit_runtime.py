#!/usr/bin/env python3
from __future__ import annotations
import json, sys, time
from datetime import datetime, timezone
from pathlib import Path

CFG  = Path("/Users/erik/Documents/qte-attestation/runner/config.toml")
RUNS = Path("/Users/erik/Documents/qte-attestation/runs"); RUNS.mkdir(parents=True, exist_ok=True)

def info(m): print(f"[·] {m}")
def ok(m="OK"): print(f"[OK] {m}")
def bad(m): print(f"[!!] {m}")

# --- config ---
info("Loading config")
try:
    try: import tomllib
    except Exception: import tomli as tomllib
    cfg = tomllib.load(open(CFG, "rb"))
    backend_name = cfg.get("backend", "ibm_marrakesh")
    shots = cfg.get("shots", 400)
    shots = int(shots[0] if isinstance(shots, (list, tuple)) else shots)
    n = int(cfg.get("n_qubits", 8))
    print(f"[OK] backend={backend_name}, shots={shots}, n={n}")
except Exception as e:
    bad(f"Failed to read config: {e}"); sys.exit(1)

# --- circuits ---
info("Building keyed/forger circuits")
try:
    from circuits import keyed_and_forger
    keyed_t, forger_t = keyed_and_forger(n, seed=int(cfg.get("key_seed", 424242)))
    ok()
except Exception as e:
    bad(f"Circuit build failed: {e}"); sys.exit(2)

# --- runtime + transpile ---
try:
    from qiskit_ibm_runtime import QiskitRuntimeService, Sampler
    from qiskit import transpile
except Exception as e:
    bad(f"Imports failed: {e}"); sys.exit(3)

info("Preparing IBM Runtime Sampler (job mode)")
try:
    svc = QiskitRuntimeService()
    backend = svc.backend(backend_name)
    sampler = Sampler(backend)  # pass BackendV2 positionally (job mode)
    ok()
except Exception as e:
    bad(f"Sampler init failed: {e}")
    sys.exit(4)

info("Transpiling circuits to backend target")
try:
    tcircs = transpile([keyed_t, forger_t], backend=backend, optimization_level=1)
    ok()
except Exception as e:
    bad(f"Transpile failed: {e}"); sys.exit(5)

# --- submit, write runlog immediately, then try short wait ---
info(f"Submitting to Runtime on {backend_name}")
try:
    job = sampler.run(tcircs, shots=shots)
    job_id = job.job_id()
    print(f"[OK] submitted job_id={job_id}")
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    runlog = RUNS / f"{ts}_runlog.json"
    with open(runlog, "w") as f:
        json.dump({"ts": ts, "backend": backend_name, "mode": "runtime",
                   "shots": shots, "job_id": str(job_id), "n_qubits": n}, f, indent=2)
    print(runlog)
except Exception as e:
    bad(f"Submit failed: {e}"); sys.exit(6)

# Try to fetch results quickly; if backend is in maintenance or long queue, exit cleanly.
try:
    # prefer a bounded wait so we don't hang your shell
    res = job.result(timeout=300)  # 5 minutes max
except Exception as e:
    bad(f"result wait timed out or failed: {e}")
    print("[·] Leave the job running or cancel it with runner/cancel_pending.py")
    sys.exit(0)

# --- counts extraction (robust) ---
def _counts(entry, shots:int):
    for path in (
        lambda: entry.data.meas.get_counts(),
        lambda: entry.data.get_counts(),
    ):
        try: return path()
        except Exception: pass
    for attr in ("quasi_dist","quasi_dists"):
        try:
            qd = getattr(entry, attr)
            if qd is not None:
                if isinstance(qd, list): qd = qd[0]
                return {k:int(round(v*shots)) for k,v in dict(qd).items()}
        except Exception: pass
    raise RuntimeError("unsupported result payload")

try:
    entries = getattr(res, "results", res)
    keyed_counts  = _counts(entries[0], shots)
    forger_counts = _counts(entries[1], shots)
except Exception as e:
    bad(f"Count extraction failed: {e}"); sys.exit(7)

jsonl = RUNS / f"{ts}_submit_counts.jsonl"
with open(jsonl,"w") as f:
    f.write(json.dumps({"tag":"keyed","backend":backend_name,"mode":"runtime",
                        "shots":shots,"n_qubits":n,"counts":keyed_counts})+"\n")
    f.write(json.dumps({"tag":"forger","backend":backend_name,"mode":"runtime",
                        "shots":shots,"n_qubits":n,"counts":forger_counts})+"\n")
print(jsonl)
