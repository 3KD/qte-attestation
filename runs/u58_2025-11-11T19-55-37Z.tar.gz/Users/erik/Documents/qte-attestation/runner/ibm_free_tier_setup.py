#!/usr/bin/env python
import os, sys, json, traceback
from qiskit_ibm_runtime import QiskitRuntimeService

INSTANCE = os.getenv("QISKIT_IBM_INSTANCE", "QIE")
BACKEND  = os.getenv("BACKEND", "ibm_torino")

def try_connect(channel, instance):
    try:
        svc = (QiskitRuntimeService(channel=channel, instance=instance)
               if (channel or instance) else QiskitRuntimeService())
        _ = svc.backends()
        return svc, None
    except Exception as e:
        return None, e

def main():
    # 1) try without specifying channel
    for ch in (None, "ibm_quantum_platform", "ibm_quantum"):
        svc, err = try_connect(ch, INSTANCE)
        if svc:
            b = svc.backend(BACKEND)
            print(json.dumps({"status":"OK","channel":ch or "auto","instance":INSTANCE,"backend":b.name}))
            return

    # 2) attempt to save using token if provided in env
    token = os.getenv("IBM_QUANTUM_TOKEN") or os.getenv("QISKIT_IBM_TOKEN")
    if token:
        for ch in ("ibm_quantum_platform", "ibm_quantum"):
            try:
                QiskitRuntimeService.save_account(channel=ch, token=token, instance=INSTANCE, overwrite=True)
                svc, err = try_connect(ch, INSTANCE)
                if svc:
                    b = svc.backend(BACKEND)
                    print(json.dumps({"status":"OK_SAVED","channel":ch,"instance":INSTANCE,"backend":b.name}))
                    return
            except Exception as e:
                err = e

    # 3) hard fail with a clear hint
    msg = "[ibm-setup] FAIL: no usable saved account for free tier.\n" \
          "Set an API token in env and re-run, e.g.:\n" \
          "  export IBM_QUANTUM_TOKEN=...  # from your IBM Quantum account\n" \
          "  QISKIT_IBM_INSTANCE=QIE BACKEND=%s ibm-setup" % BACKEND
    print(msg, file=sys.stderr)
    sys.exit(1)

if __name__ == "__main__":
    main()
