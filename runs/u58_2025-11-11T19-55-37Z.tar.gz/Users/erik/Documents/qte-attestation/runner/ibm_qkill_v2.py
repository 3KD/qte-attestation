#!/usr/bin/env python3
import argparse, sys
from qiskit_ibm_runtime import QiskitRuntimeService

CANCELABLE = {"QUEUED","RUNNING","INITIALIZING","VALIDATING","TRANSFERRING"}

def job_state(j):
    try:
        s = j.status()
        return getattr(s, "name", str(s)).upper()
    except Exception:
        return "UNKNOWN"

def job_backend_name(j):
    try:
        b = j.backend()
        return getattr(b, "name", None) or str(b)
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser(
        description="Cancel IBM Runtime jobs (free tier compatible)."
    )
    ap.add_argument("--backend", help="Only act on jobs from this backend name (e.g. ibm_torino)")
    ap.add_argument("--state", default="QUEUED,RUNNING",
                    help="Comma list of states to cancel (default: QUEUED,RUNNING). "
                         "Other possible states include INITIALIZING, VALIDATING, TRANSFERRING.")
    ap.add_argument("--limit", type=int, default=50, help="How many recent jobs to inspect (default: 50)")
    ap.add_argument("--dry-run", action="store_true", help="Show what would be cancelled, but don’t cancel")
    ap.add_argument("--yes", action="store_true", help="Don’t ask for confirmation")
    args = ap.parse_args()

    svc = QiskitRuntimeService()
    # NOTE: free tier API here: no backend= kw; we filter locally.
    jobs = svc.jobs(limit=args.limit)

    want_states = {s.strip().upper() for s in args.state.split(",") if s.strip()}
    targets = []
    for j in jobs:
        state = job_state(j)
        bname = job_backend_name(j)
        if want_states and state not in want_states:
            continue
        if args.backend and (bname or "").lower() != args.backend.lower():
            continue
        targets.append((j, state, bname))

    if not targets:
        print("[ibm_qkill] nothing to do (no jobs match filters).")
        sys.exit(0)

    print("[ibm_qkill] candidates:\n")
    for j, state, bname in targets:
        print(f"  {j.job_id()}  {state:12s}  {bname or '-'}")

    if args.dry_run:
        print("\n[ibm_qkill] DRY RUN — no cancellations performed.")
        return

    if not args.yes:
        try:
            resp = input("\nCancel ALL listed jobs? [y/N] ").strip().lower()
        except KeyboardInterrupt:
            print("\n[ibm_qkill] cancelled by user.")
            sys.exit(130)
        if resp not in ("y","yes"):
            print("[ibm_qkill] aborting.")
            return

    errs = 0
    for j, state, bname in targets:
        try:
            j.cancel()
            print(f"[OK] cancelled {j.job_id()} ({state}, {bname or '-'})")
        except Exception as e:
            errs += 1
            print(f"[!!] failed to cancel {j.job_id()}: {e}")

    if errs:
        sys.exit(1)

if __name__ == "__main__":
    main()
