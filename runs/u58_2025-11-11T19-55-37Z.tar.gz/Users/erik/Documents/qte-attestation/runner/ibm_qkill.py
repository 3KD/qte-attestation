#!/usr/bin/env python3
import argparse, sys
from qiskit_ibm_runtime import QiskitRuntimeService

def main():
    ap = argparse.ArgumentParser(description="Cancel IBM Runtime jobs (panic button).")
    ap.add_argument("--backend", help="Only cancel jobs on this backend (e.g., ibm_torino)")
    ap.add_argument("--limit", type=int, default=200, help="How many recent jobs to inspect (default 200)")
    ap.add_argument("--dry-run", action="store_true", help="Show what would be cancelled, but do nothing")
    args = ap.parse_args()

    svc = QiskitRuntimeService()
    jobs = svc.jobs(limit=args.limit, backend=args.backend)
    target_states = {"QUEUED","RUNNING","VALIDATING","CREATING"}
    to_cancel = []
    for j in jobs:
        st = str(j.status())
        if any(s in st for s in target_states):
            to_cancel.append(j)

    if not to_cancel:
        print("[qkill] nothing to cancel."); return

    print(f"[qkill] found {len(to_cancel)} cancellable job(s){' (dry-run)' if args.dry_run else ''}:")
    for j in to_cancel:
        print(f"  {j.job_id}: {j.backend()} {j.status()}")
    if args.dry_run:
        return

    ok = 0; fail = 0
    for j in to_cancel:
        try:
            j.cancel()
            print(f"[qkill] CANCELLED {j.job_id}")
            ok += 1
        except Exception as e:
            print(f"[qkill] FAILED    {j.job_id}: {e}")
            fail += 1
    print(f"[qkill] done. cancelled={ok} failed={fail}")

if __name__ == "__main__":
    main()
