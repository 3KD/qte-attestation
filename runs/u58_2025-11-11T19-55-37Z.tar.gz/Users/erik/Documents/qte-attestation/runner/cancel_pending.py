#!/usr/bin/env python3
from qiskit_ibm_runtime import QiskitRuntimeService
svc = QiskitRuntimeService()  # uses your saved account/instance
n = 0
for job in svc.jobs(limit=50, descending=True):
    st = str(job.status()).lower()
    if any(k in st for k in ("queued","validat","running","initializ")):
        try:
            job.cancel()
            print("CANCELED", job.job_id(), st)
            n += 1
        except Exception as e:
            print("SKIP", job.job_id(), st, e)
print("total canceled:", n)
