import json, time
from pathlib import Path

# config
try:
    import tomllib as tomli
except Exception:
    import tomli as tomli

CFG_P = Path("/Users/erik/Documents/qte-attestation/runner/config.toml")
cfg = tomli.load(open(CFG_P, "rb"))
backend_name = cfg.get("backend", "ibm_marrakesh")
shots        = int(cfg.get("shots", 400))
n            = int(cfg.get("n_qubits", 8))

# make timestamp + run paths
ts = time.strftime("%Y-%m-%dT%H-%M-%SZ", time.gmtime())
RUNS = Path("/Users/erik/Documents/qte-attestation/runs")
RUNS.mkdir(parents=True, exist_ok=True)
jsonl = RUNS / f"{ts}_submit_counts.jsonl"
runlog = RUNS / f"{ts}_runlog.json"

# circuits (import from runner/circuits.py)
import sys
sys.path.append(str(Path(__file__).parent))
from circuits import keyed_and_forger

from qiskit import transpile
from qiskit_ibm_provider import IBMProvider

keyed, forger = keyed_and_forger(n=n, seed=int(cfg.get("key_seed", 0)))

prov = IBMProvider()  # uses your saved account; no token writes
backend = prov.get_backend(backend_name)

t_keyed  = transpile(keyed,  backend=backend, optimization_level=1)
t_forger = transpile(forger, backend=backend, optimization_level=1)

job = backend.run([t_keyed, t_forger], shots=shots)
result = job.result()

# collect counts in the same format harvester expects
counts_list = result.get_counts()
rec_keyed = {
    "tag":"keyed","backend":backend_name,"mode":"provider",
    "shots":shots,"n_qubits":n,"counts":counts_list[0]
}
rec_forg  = {
    "tag":"forger","backend":backend_name,"mode":"provider",
    "shots":shots,"n_qubits":n,"counts":counts_list[1]
}

# write artifacts
with open(jsonl,"w") as f:
    f.write(json.dumps(rec_keyed)+"\n")
    f.write(json.dumps(rec_forg)+"\n")

with open(runlog,"w") as f:
    json.dump({
        "ts": ts,
        "backend": backend_name,
        "mode": "provider",
        "shots": shots,
        "job_id": str(job.job_id()),
        "n_qubits": n
    }, f, indent=2)

print(jsonl)
print(runlog)
