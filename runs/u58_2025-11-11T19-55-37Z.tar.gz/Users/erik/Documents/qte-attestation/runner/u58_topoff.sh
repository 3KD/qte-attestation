#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/Users/erik/Documents/qte-attestation}"
BACKEND="${BACKEND:-ibm_torino}"
PAIRS="${PAIRS:-2}"
ENV="${ENV:-qte-ibm311}"

echo "[u58-topoff] env=$ENV backend=$BACKEND pairs=$PAIRS"

# sanity: ensure free-tier account/instance is usable BEFORE submitting anything
if ! conda run -n "$ENV" env QISKIT_IBM_INSTANCE=${QISKIT_IBM_INSTANCE:-QIE} BACKEND="$BACKEND" \
     "$BASE/runner/ibm_free_tier_setup.py" >/dev/null; then
  echo "[u58-topoff] aborting: IBM account/instance not set for free tier (see ibm-setup output)" >&2
  exit 1
fi

for i in $(seq 1 "$PAIRS"); do
  echo "[u58-topoff] submitting pair $i/$PAIRS ..."
  BACKEND="$BACKEND" \
  conda run -n "$ENV" env QISKIT_IBM_INSTANCE=${QISKIT_IBM_INSTANCE:-QIE} \
    "$BASE/runner/submit_runtime.py" || true

  conda run -n "$ENV" env QISKIT_IBM_INSTANCE=${QISKIT_IBM_INSTANCE:-QIE} \
    "$BASE/runner/await_then_harvest.py" || true
done

# aggregate and print ROC
N=$((PAIRS+10))
conda run -n "$ENV" env QISKIT_IBM_INSTANCE=${QISKIT_IBM_INSTANCE:-QIE} \
  "$BASE/runner/aggregate_attestation.py" --backend "$BACKEND" --limit "$N" --show-roc || true

# optional: CI
if command -v u58-ci >/dev/null 2>&1; then u58-ci || true; fi

# bundle + hash latest aggregate and its sources
U58_JSON="$(ls -t "$BASE"/runs/*_U58_attestation.json | head -1)"
TS="$(jq -r '.ts' "$U58_JSON")"
BUNDLE="$BASE/runs/u58_${TS}.tar.gz"
echo "[u58-topoff] bundling artifacts for ts=$TS ..."
tar -czf "$BUNDLE" "$BASE/runner" "$U58_JSON" $(jq -r '.source_paths[]' "$U58_JSON")
shasum -a 256 "$BUNDLE" | tee "$BUNDLE.sha256"
echo "[u58-topoff] done -> $BUNDLE"
