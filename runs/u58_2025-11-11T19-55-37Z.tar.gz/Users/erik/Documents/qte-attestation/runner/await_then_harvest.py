#!/usr/bin/env python3
import json, sys, time, pathlib, subprocess, shutil

BASE = pathlib.Path("/Users/erik/Documents/qte-attestation")
RUNS = BASE / "runs"

# ---------- helpers ----------
def latest_runlog() -> pathlib.Path:
    files = sorted(RUNS.glob("*_runlog.json"))
    if not files:
        print("[!!] No runlog found.", file=sys.stderr); sys.exit(2)
    return files[-1]

def as_bits(k, n: int) -> str:
    if isinstance(k, int): return format(k, f"0{n}b")
    s = str(k)
    if s.startswith(("0x","0X")): return format(int(s,16), f"0{n}b")
    if s.isdigit(): return format(int(s), f"0{n}b")
    return s.zfill(n)

def coerce_counts(m, n: int, shots: int):
    # accept probs or counts; round + fix total to shots
    try:
        vals = [float(v) for v in m.values()]
        s = sum(vals)
    except Exception:
        raise ValueError("not mapping-like")
    out = {as_bits(k,n): float(v) for k,v in m.items()}
    if 0.95 <= s <= 1.05:              # probs → counts
        out = {k:int(round(v*shots)) for k,v in out.items()}
    else:                               # counts-ish → ints
        out = {k:int(round(v)) for k,v in out.items()}
    diff = shots - sum(out.values())
    if diff:
        kmax = max(out, key=out.get)
        out[kmax] += diff
    return out

def counts_from_array(a, n: int):
    import numpy as np
    a = np.asarray(a)
    if a.ndim == 2 and a.shape[1] == n:
        counts = {}
        for row in a:
            b = "".join("1" if int(x) else "0" for x in row)
            counts[b] = counts.get(b,0) + 1
        return counts
    if a.ndim == 1:
        counts = {}
        for v in a:
            b = as_bits(int(v), n)
            counts[b] = counts.get(b,0) + 1
        return counts
    raise ValueError(f"bad shape {a.shape}")

def pubs_from_result(res):
    # try indexing
    pubs = []
    try:
        i = 0
        while True:
            pubs.append(res[i]); i += 1
            if i >= 8: break
    except Exception:
        pubs = []
    if pubs: return pubs
    # iteration
    try: pubs = list(res)
    except Exception: pubs = []
    if pubs: return pubs
    # known attrs
    for attr in ("pub_results","results","pubs","_pub_results","_results","data"):
        try:
            cand = getattr(res, attr, None)
            if cand is None: continue
            return list(cand) if hasattr(cand,"__iter__") and not isinstance(cand,(str,bytes,dict)) else [cand]
        except Exception:
            pass
    return []

def extract_counts_from_pub(pub, n: int, shots: int):
    """
    Robust path for SamplerPubResult with DataBin(c=BitArray).
    1) Prefer pub.join_data().c.array  → numpy → counts
    2) Else fall back to pub.data.c and try .array / buffer / numpy
    3) Else try dict-like conversions (older quasi_dists)
    """
    import numpy as np

    # ---- 1) join_data() path (works on your payload)
    joined = getattr(pub, "join_data", None)
    if callable(joined):
        try:
            j = joined()                          # DataBin
            c = getattr(j, "c", None)
            if c is not None:
                arr = getattr(c, "array", None)   # BitArray.array
                if arr is not None:
                    # try direct array
                    try:
                        a = np.array(arr, copy=False)
                    except Exception:
                        try: a = np.asarray(arr)
                        except Exception:
                            a = None
                    # if 2D shots×n of {0,1}, easy path
                    if a is not None:
                        if a.ndim == 2 and a.shape[1] == n:
                            return counts_from_array(a, n)
                        if a.ndim == 1:
                            # possibly bit-packed bytes → unpack
                            if a.dtype == np.uint8:
                                bits = np.unpackbits(a)
                                if bits.size >= shots*n:
                                    bits = bits[:shots*n].reshape(shots, n)
                                    return counts_from_array(bits, n)
                    # buffer fallback (some builds expose buffer but np.array fails)
                    try:
                        buf = memoryview(arr).tobytes()
                        u8 = np.frombuffer(buf, dtype=np.uint8)
                        bits = np.unpackbits(u8)
                        if bits.size >= shots*n:
                            bits = bits[:shots*n].reshape(shots, n)
                            return counts_from_array(bits, n)
                    except Exception:
                        pass
        except Exception:
            pass

    # ---- 2) raw DataBin.c path
    data = getattr(pub, "data", None) or getattr(pub, "_data", None) or pub
    c = getattr(data, "c", None)
    if c is not None:
        # dict-ish fallback
        if isinstance(c, dict):
            try: return coerce_counts(c, n, shots)
            except Exception: pass
        # attr 'array'
        arr = getattr(c, "array", None)
        if arr is not None:
            try:
                a = np.array(arr, copy=False)
            except Exception:
                try: a = np.asarray(arr)
                except Exception: a = None
            if a is not None:
                if a.ndim == 2 and a.shape[1] == n:
                    return counts_from_array(a, n)
                if a.ndim == 1 and a.dtype == np.uint8:
                    bits = np.unpackbits(a)
                    if bits.size >= shots*n:
                        bits = bits[:shots*n].reshape(shots, n)
                        return counts_from_array(bits, n)
            # buffer fallback
            try:
                buf = memoryview(arr).tobytes()
                u8 = np.frombuffer(buf, dtype=np.uint8)
                bits = np.unpackbits(u8)
                if bits.size >= shots*n:
                    bits = bits[:shots*n].reshape(shots, n)
                    return counts_from_array(bits, n)
            except Exception:
                pass

    # ---- 3) last resort: mapping on pub itself
    for name in ("to_dict","dict"):
        f = getattr(pub, name, None)
        if callable(f):
            try:
                d = f()
                if isinstance(d, dict):
                    return coerce_counts(d, n, shots)
            except Exception:
                pass

    raise RuntimeError("BitArray→counts conversion failed")

# ---------- main ----------
def main():
    runlog_path = latest_runlog()
    runlog = json.load(open(runlog_path))
    job_id = runlog["job_id"]; backend = runlog["backend"]
    shots = int(runlog.get("shots", 400)); n = int(runlog.get("n_qubits", 8))
    ts = runlog["ts"]

    print(f"[·] Monitoring job {job_id} on {backend}")
    from qiskit_ibm_runtime import QiskitRuntimeService
    svc = QiskitRuntimeService()
    job = svc.job(job_id)

    last = None; t0 = time.time()
    while True:
        try:
            s = job.status(); sval = getattr(s, "value", str(s))
        except Exception as e:
            sval = f"STATUS_ERROR:{e}"
        if sval != last:
            print(f"[~] {sval}  (t+{int(time.time()-t0)}s)", flush=True)
            last = sval
        if sval in ("DONE","CANCELLED","ERROR","FAILURE","FAILED") or sval.startswith("STATUS_ERROR"):
            break
        time.sleep(5)

    if sval != "DONE":
        print(f"[!!] Job finished with state {sval}", file=sys.stderr); sys.exit(1)

    print("[·] Fetching result…")
    res = job.result()

    # A) quasi_dists (older)
    qd = getattr(res, "quasi_dists", None)
    if isinstance(qd, (list,tuple)) and qd:
        counts = [coerce_counts(q, n, shots) for q in qd]
    else:
        # B) PrimitiveResult with SamplerPubResult + DataBin(BitArray)
        pubs = pubs_from_result(res)
        if not pubs:
            info = {"type": type(res).__name__, "repr": str(res)[:600]}
            raise RuntimeError("Unsupported Sampler payload: "+json.dumps(info))
        counts = []
        for pub in pubs[:2]:
            try:
                counts.append(extract_counts_from_pub(pub, n, shots))
            except Exception as e:
                continue
        if len(counts) < 2:
            info = {"type": type(res).__name__, "repr": str(res)[:600]}
            raise RuntimeError("Could not extract 2 count sets from pubs: "+json.dumps(info))

    counts_keyed, counts_forg = counts[:2]

    def top3(c): 
        ks = sorted(c, key=c.get, reverse=True)[:3]
        return ", ".join(f"{k}:{c[k]}" for k in ks)
    print(f"[OK] keyed top:  {top3(counts_keyed)}")
    print(f"[OK] forger top: {top3(counts_forg)}")

    jsonl_path = RUNS / f"{ts}_submit_counts.jsonl"
    with open(jsonl_path, "w") as f:
        f.write(json.dumps({"tag":"keyed","backend":backend,"mode":"runtime","shots":shots,"n_qubits":n,"counts":counts_keyed})+"\n")
        f.write(json.dumps({"tag":"forger","backend":backend,"mode":"runtime","shots":shots,"n_qubits":n,"counts":counts_forg})+"\n")
    print("[OK] wrote", jsonl_path)

    exe = shutil.which("qte-attestation") or str(BASE/".venv/bin/qte-attestation")
    ksucc = counts_keyed.get("0"*n, 0)
    fsucc = counts_forg.get("0"*n, 0)
    cmd = [
        exe, "verify",
        "--keyed-succ", str(ksucc), "--keyed-trials", str(shots),
        "--forg-succ",  str(fsucc), "--forg-trials",  str(shots),
        "--alpha","0.05","--min-accept","0.99","--max-forge","0.01",
    ]
    print("Running:", " ".join(cmd), flush=True)
    sys.exit(subprocess.run(cmd).returncode)

if __name__ == "__main__":
    main()
