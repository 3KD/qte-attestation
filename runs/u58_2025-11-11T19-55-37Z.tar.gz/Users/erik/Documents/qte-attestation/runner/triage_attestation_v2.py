#!/usr/bin/env python3
# Summarize attestation runs under ./runs:
# - Finds *_runlog.json
# - Loads *_submit_counts.jsonl if present
# - Reports smallest PASS radius r where CP_lo(keyed)>=0.99 and CP_hi(forg)<=0.01
# - Verbose by default so you see what it's doing

import os, sys, json, pathlib, argparse
from collections import Counter

def detect_base() -> pathlib.Path:
    # Prefer env BASE, else derive from this file's location
    b = os.environ.get("BASE")
    if b:
        return pathlib.Path(b).expanduser().resolve()
    return pathlib.Path(__file__).resolve().parents[1]

def load_json(p: pathlib.Path):
    try:
        with open(p, "r") as f:
            return json.load(f)
    except Exception as e:
        print(f"[!] failed to read {p}: {e}")
        return None

def load_jsonl_counts(jsonl_path: pathlib.Path):
    if not jsonl_path.exists():
        return None
    keyed = forg = None
    shots = n = None
    try:
        with open(jsonl_path, "r") as f:
            for line in f:
                rec = json.loads(line)
                if rec.get("tag") == "keyed":
                    keyed = Counter(rec["counts"])
                    shots = rec["shots"]; n = rec["n_qubits"]
                elif rec.get("tag") == "forger":
                    forg = Counter(rec["counts"])
                    shots = rec["shots"]; n = rec["n_qubits"]
        if keyed and forg and shots and n is not None:
            return {"keyed": keyed, "forger": forg, "shots": shots, "n": n}
    except Exception as e:
        print(f"[!] bad JSONL {jsonl_path}: {e}")
    return None

def cp_bounds(k, N, alpha=0.05):
    # exact Clopper–Pearson via SciPy (present in your env)
    from scipy.stats import beta
    lo = 0.0 if k == 0 else float(beta.ppf(alpha/2, k, N-k+1))
    hi = 1.0 if k == N else float(beta.ppf(1 - alpha/2, k+1, N-k))
    return lo, hi

def succ_leq_r(counts: Counter, r: int) -> int:
    return sum(v for b,v in counts.items() if b.count("1") <= r)

def minimal_pass_r(keyed: Counter, forg: Counter, shots: int, n: int, alpha=0.05):
    for r in range(n+1):
        ks = succ_leq_r(keyed, r)
        fs = succ_leq_r(forg,  r)
        klo, _ = cp_bounds(ks, shots, alpha)
        _, fhi = cp_bounds(fs, shots, alpha)
        if (klo >= 0.99) and (fhi <= 0.01):
            return r, ks, fs, klo, fhi
    return None, None, None, None, None

def top3(c: Counter, k=3):
    if not c: return "-"
    items = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:k]
    return ", ".join(f"{b}:{v}" for b,v in items)

def main():
    base = detect_base()
    runs_dir = base / "runs"
    print(f"[triage] BASE={base}")
    print(f"[triage] RUNS={runs_dir}")
    if not runs_dir.exists():
        print("[triage] runs/ not found"); sys.exit(1)

    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", help="filter by backend (exact match)")
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--show-top", action="store_true")
    args = ap.parse_args()

    runlogs = sorted(runs_dir.glob("*_runlog.json"))
    print(f"[triage] found {len(runlogs)} runlog(s)")
    if not runlogs:
        sys.exit(1)
    runlogs = runlogs[-args.limit:]

    # header
    cols = ["ts","backend","job_id","shots","n","status","k@r0","f@r0","k@r*","CP_lo(k)","CP_hi(f)"]
    if args.show_top: cols += ["keyed_top3","forger_top3"]
    rows = []

    matched = 0
    for rl in runlogs:
        meta = load_json(rl) or {}
        backend = meta.get("backend")
        if args.backend and backend != args.backend:
            continue
        matched += 1
        ts = meta.get("ts","?")
        jid = meta.get("job_id","?")
        jsonl = rl.with_name(rl.name.replace("_runlog.json","_submit_counts.jsonl"))
        bundle = load_jsonl_counts(jsonl)
        if not bundle:
            rows.append([ts, backend, jid, "-", "-", "MISSING", "-", "-", "-", "-", "-"] + (["-","-"] if args.show_top else []))
            continue

        keyed, forg = bundle["keyed"], bundle["forger"]
        shots, n   = bundle["shots"], bundle["n"]
        rstar, ks, fs, klo, fhi = minimal_pass_r(keyed, forg, shots, n, alpha=args.alpha)
        status = f"PASS r={rstar}" if rstar is not None else "FAIL all r"
        rows.append([
            ts, backend, jid, shots, n, status,
            f"{succ_leq_r(keyed,0)}/{shots}",
            f"{succ_leq_r(forg,0)}/{shots}",
            (f"{ks}/{shots}" if ks is not None else "-"),
            (f"{klo:.5f}" if klo is not None else "-"),
            (f"{fhi:.5f}" if fhi is not None else "-"),
        ] + ([top3(keyed), top3(forg)] if args.show_top else []))

    if matched == 0:
        print(f"[triage] no runs matched backend filter {args.backend!r}")
        sys.exit(1)

    # pretty print (fixed-width)
    widths = [max(len(str(r[i])) for r in ([cols]+rows)) for i in range(len(cols))]
    print("\n" + " ".join(c.ljust(widths[i]) for i,c in enumerate(cols)))
    for r in rows:
        print(" ".join(str(v).ljust(widths[i]) for i,v in enumerate(r)))

