#!/usr/bin/env python3
import getpass, os, sys, json
from qiskit_ibm_runtime import QiskitRuntimeService

CHANNEL  = "ibm_quantum_platform"
INSTANCE = os.getenv("QISKIT_IBM_INSTANCE", "QIE")
BACKEND  = os.getenv("BACKEND", "ibm_torino")

def main():
    print(f"[ibm-save] Will store free-tier account (channel={CHANNEL}, instance={INSTANCE}).")
    token = os.getenv("IBM_QUANTUM_TOKEN") or getpass.getpass("IBM Quantum API token (input hidden): ").strip()
    if not token:
        print("[ibm-save] No token provided. Aborting.", file=sys.stderr); sys.exit(1)

    # Clean out any confusing old entries.
    for ch in ("ibm_quantum", "ibm_quantum_platform", "ibm_cloud"):
        try: QiskitRuntimeService.delete_account(channel=ch)
        except Exception: pass

    # Save the correct one.
    QiskitRuntimeService.save_account(
        channel=CHANNEL,
        token=token,
        instance=INSTANCE,
        overwrite=True,
    )

    # Verify we can resolve the backend using the saved account.
    svc = QiskitRuntimeService(channel=CHANNEL, instance=INSTANCE)
    b = svc.backend(BACKEND)
    print(json.dumps({"status":"OK","channel":CHANNEL,"instance":INSTANCE,"backend":b.name}))
    print("[ibm-save] Saved & verified.")
if __name__ == "__main__":
    main()
