#!/usr/bin/env python3
import json, pathlib, random, collections, sys

def hw(b): return b.count("1")
def succ_leq_r(C, r): return sum(v for k,v in C.items() if hw(k) <= r)

def load_latest_u58_json(runs: pathlib.Path):
    files = sorted(runs.glob("*_U58_attestation.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files: print("[u58-ci] no *_U58_attestation.json found", file=sys.stderr); sys.exit(1)
    data = json.load(open(files[0]))
    return files[0], data

def load_pairs(paths):
    out = []
    for p in paths:
        recs = [json.loads(x) for x in open(p)]
        K = next(r["counts"] for r in recs if r.get("tag")=="keyed")
        F = next(r["counts"] for r in recs if r.get("tag")=="forger")
        shots = int(next(r["shots"] for r in recs if r.get("tag")=="keyed"))
        n = int(next(r["n_qubits"] for r in recs if r.get("tag")=="keyed"))
        out.append((collections.Counter({k:int(v) for k,v in K.items()}),
                    collections.Counter({k:int(v) for k,v in F.items()}),
                    n, shots))
    return out

def tpr_at_1pct(Ksum, Fsum, n, total_shots):
    best = 0.0
    for r in range(n+1):
        ks = succ_leq_r(Ksum, r)
        fs = succ_leq_r(Fsum, r)
        FPR = fs/total_shots
        if FPR <= 0.01:
            best = max(best, ks/total_shots)
    return best

def main():
    runs = pathlib.Path("/Users/erik/Documents/qte-attestation/runs")
    jpath, agg = load_latest_u58_json(runs)
    pairs = load_pairs(agg["source_paths"])
    if not pairs: print("[u58-ci] empty source_paths in", jpath, file=sys.stderr); sys.exit(1)

    B = 400
    rnd = random.Random(1337)
    vals = []
    m = len(pairs)
    n = pairs[0][2]
    shots = pairs[0][3]
    for _ in range(B):
        Ksum = collections.Counter(); Fsum = collections.Counter()
        for __ in range(m):
            K,F,_,_ = pairs[rnd.randrange(m)]
            Ksum.update(K); Fsum.update(F)
        total_shots = shots*m
        vals.append(tpr_at_1pct(Ksum, Fsum, n, total_shots))
    vals.sort()
    lo, hi = vals[int(0.02*B)], vals[int(0.98*B)]
    mean = sum(vals)/B

    print(f"[u58-ci] latest: {jpath.name}")
    print(f"TPR@1%FPR bootstrap 95% CI: {lo:.4f}–{hi:.4f}  (mean={mean:.4f})")
    print(f"(AUC in file: {agg['AUC']:.4f}, CI: {agg['AUC_CI_95'][0]:.4f}–{agg['AUC_CI_95'][1]:.4f})")

if __name__ == "__main__":
    main()
