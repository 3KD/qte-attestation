#!/usr/bin/env python3
import os, sys, json, pathlib, argparse, subprocess
from collections import Counter

def detect_base() -> pathlib.Path:
    b = os.environ.get("BASE")
    return pathlib.Path(b).expanduser().resolve() if b else pathlib.Path(__file__).resolve().parents[1]

def load_json(p: pathlib.Path):
    with open(p, "r") as f:
        return json.load(f)

def load_jsonl_counts(jsonl_path: pathlib.Path):
    if not jsonl_path.exists():
        return None
    keyed = forg = None; shots = n = None
    with open(jsonl_path, "r") as f:
        for line in f:
            rec = json.loads(line)
            if rec.get("tag") == "keyed":
                keyed = Counter(rec["counts"]); shots = rec["shots"]; n = rec["n_qubits"]
            elif rec.get("tag") == "forger":
                forg = Counter(rec["counts"]); shots = rec["shots"]; n = rec["n_qubits"]
    if keyed and forg and shots and n is not None:
        return {"keyed": keyed, "forger": forg, "shots": shots, "n": n}
    return None

def cp_bounds(k, N, alpha=0.05):
    try:
        from scipy.stats import beta
        lo = 0.0 if k == 0 else float(beta.ppf(alpha/2, k, N-k+1))
        hi = 1.0 if k == N else float(beta.ppf(1 - alpha/2, k+1, N-k))
        return lo, hi
    except Exception:
        # fallback: Wilson (good enough for triage visibility)
        from math import sqrt
        z = 1.959963984540054 # 95% two-sided
        phat = k/N
        denom = 1 + z*z/N
        center = (phat + z*z/(2*N)) / denom
        rad = z*sqrt((phat*(1-phat)+z*z/(4*N))/N) / denom
        return max(0.0, center-rad), min(1.0, center+rad)

def succ_leq_r(counts: Counter, r: int) -> int:
    return sum(v for b,v in counts.items() if b.count("1") <= r)

def minimal_pass_r(keyed: Counter, forg: Counter, shots: int, n: int, alpha=0.05):
    for r in range(n+1):
        ks = succ_leq_r(keyed, r)
        fs = succ_leq_r(forg,  r)
        klo, _ = cp_bounds(ks, shots, alpha)
        _, fhi = cp_bounds(fs, shots, alpha)
        if (klo >= 0.99) and (fhi <= 0.01):
            return r, ks, fs, klo, fhi
    return None, None, None, None, None

def top3(c: Counter, k=3):
    if not c: return "-"
    items = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:k]
    return ", ".join(f"{b}:{v}" for b,v in items)

def rehydrate_once(base: pathlib.Path):
    # call your existing harvester; it pulls the newest runlog's job_id and writes *_submit_counts.jsonl
    runner = base/"runner"/"await_then_harvest.py"
    if not runner.exists():
        print("[triage] cannot rehydrate: runner/await_then_harvest.py not found")
        return False
    print("[triage] rehydrating via await_then_harvest.py ...")
    r = subprocess.run([str(runner)], stdout=sys.stdout, stderr=sys.stderr)
    return r.returncode == 0

def main():
    base = detect_base()
    runs_dir = base / "runs"
    print(f"[triage] BASE={base}")
    print(f"[triage] RUNS={runs_dir}")
    if not runs_dir.exists():
        print("[triage] runs/ not found"); sys.exit(1)

    ap = argparse.ArgumentParser(description="Triage attestation runs")
    ap.add_argument("--backend", help="filter by backend (exact match)")
    ap.add_argument("--limit", type=int, default=50)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--rehydrate", action="store_true", help="if counts missing, call await_then_harvest.py once")
    ap.add_argument("--show-top", action="store_true")
    args = ap.parse_args()

    runlogs = sorted(runs_dir.glob("*_runlog.json"))
    print(f"[triage] found {len(runlogs)} runlog(s) total")
    if not runlogs:
        sys.exit(1)
    runlogs = runlogs[-args.limit:]

    cols = ["ts","backend","job_id","shots","n","status","k@r0","f@r0","k@r*","CP_lo(k)","CP_hi(f)"]
    if args.show_top: cols += ["keyed_top3","forger_top3"]
    rows = []
    matched = 0
    passes = 0
    rs_hist = {}

    for rl in runlogs:
        try:
            meta = load_json(rl)
        except Exception as e:
            print(f"[triage] skip {rl.name}: {e}")
            continue

        backend = meta.get("backend")
        if args.backend and backend != args.backend:
            continue
        matched += 1
        ts = meta.get("ts","?")
        jid = meta.get("job_id","?")
        jsonl = rl.with_name(rl.name.replace("_runlog.json","_submit_counts.jsonl"))
        bundle = load_jsonl_counts(jsonl)

        if not bundle and args.rehydrate:
            if rehydrate_once(base):
                bundle = load_jsonl_counts(jsonl)

        if not bundle:
            rows.append([ts, backend, jid, "-", "-", "MISSING", "-", "-", "-", "-", "-"] + (["-","-"] if args.show_top else []))
            continue

        keyed, forg = bundle["keyed"], bundle["forger"]
        shots, n   = bundle["shots"], bundle["n"]
        rstar, ks, fs, klo, fhi = minimal_pass_r(keyed, forg, shots, n, alpha=args.alpha)
        if rstar is not None:
            status = f"PASS r={rstar}"
            passes += 1
            rs_hist[rstar] = rs_hist.get(rstar, 0) + 1
        else:
            status = "FAIL all r"

        rows.append([
            ts, backend, jid, shots, n, status,
            f"{succ_leq_r(keyed,0)}/{shots}",
            f"{succ_leq_r(forg,0)}/{shots}",
            (f"{ks}/{shots}" if ks is not None else "-"),
            (f"{klo:.5f}" if klo is not None else "-"),
            (f"{fhi:.5f}" if fhi is not None else "-"),
        ] + ([top3(keyed), top3(forg)] if args.show_top else []))

    if matched == 0:
        print(f"[triage] no runs matched backend filter {args.backend!r}")
        sys.exit(1)

    widths = [max(len(str(r[i])) for r in ([cols]+rows)) for i in range(len(cols))]
    print("\n" + " ".join(c.ljust(widths[i]) for i,c in enumerate(cols)))
    for r in rows:
        print(" ".join(str(v).ljust(widths[i]) for i,v in enumerate(r)))

    total = len(rows)
    fails = total - passes
    print(f"\n[triage] summary: total={total}  PASS={passes}  FAIL={fails}")
    if rs_hist:
        order = sorted(rs_hist.items())
        print("[triage] PASS radii histogram:", ", ".join(f"r={r}:{c}" for r,c in order))

if __name__ == "__main__":
    main()
