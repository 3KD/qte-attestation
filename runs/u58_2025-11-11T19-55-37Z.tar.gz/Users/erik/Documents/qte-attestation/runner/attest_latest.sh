#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/Users/erik/Documents/qte-attestation}"
"$BASE/runner/await_then_harvest.py" || true
"$BASE/runner/attest_from_counts.py"
