#!/usr/bin/env python3
# Tiny IBM Runtime job helper: list / status / watch / cancel / cancel-pending
# Default backend scope comes from latest *_runlog.json if not provided.
import argparse, json, pathlib, sys, time
from qiskit_ibm_runtime import QiskitRuntimeService

RUNS = pathlib.Path("/Users/erik/Documents/qte-attestation/runs")

PENDING = {"QUEUED","RUNNING","VALIDATING","INITIALIZING"}
TERMINAL = {"DONE","CANCELLED","ERROR"}

def latest_backend():
    try:
        p = sorted(RUNS.glob("*_runlog.json"))[-1]
        return json.load(open(p))["backend"]
    except Exception:
        return None

def svc():
    return QiskitRuntimeService()

def back_name(j):
    try: return j.backend().name
    except Exception: return "?"

def show(j):
    print(j.job_id(), str(j.status()), back_name(j))

def cmd_list(args):
    s = svc()
    count = 0
    for j in s.jobs(limit=args.limit, descending=True):
        if args.backend and back_name(j) != args.backend: continue
        show(j); count += 1
    if count == 0: print("(no jobs)")

def cmd_status(args):
    s = svc()
    for jid in args.job_id:
        j = s.job(jid); show(j)

def cmd_watch(args):
    s = svc()
    j = s.job(args.job_id)
    print("Watching", j.job_id(), "on", back_name(j))
    last = None
    while True:
        st = str(j.status())
        if st != last:
            print(time.strftime("[%H:%M:%S]"), st)
            last = st
        if st.upper() in TERMINAL:
            try:
                md = j.result().metadata
                span = md.get("execution",{}).get("execution_spans",None)
                if span: print("execution_spans:", span)
            except Exception: pass
            break
        time.sleep(args.interval)

def cmd_cancel(args):
    s = svc()
    for jid in args.job_id:
        j = s.job(jid)
        try:
            j.cancel(); print("CANCELED", j.job_id(), back_name(j))
        except Exception as e:
            print("SKIP    ", j.job_id(), "|", e)

def cmd_cancel_pending(args):
    s = svc()
    backend = args.backend or latest_backend()
    n = 0
    for j in s.jobs(limit=args.limit, descending=True):
        st = str(j.status()).upper()
        if backend and back_name(j) != backend: continue
        if st in PENDING:
            try:
                j.cancel(); print("CANCELED", j.job_id(), st, back_name(j)); n += 1
            except Exception as e:
                print("SKIP    ", j.job_id(), st, back_name(j), "|", e)
    print("total canceled:", n)

def cmd_latest(args):
    try:
        p = sorted(RUNS.glob("*_runlog.json"))[-1]
        print(json.dumps(json.load(open(p)), indent=2))
    except Exception as e:
        print("no runlog:", e); sys.exit(1)

def main():
    ap = argparse.ArgumentParser(prog="qjobs", description="IBM Runtime job helper")
    sub = ap.add_subparsers(required=True)

    ap_list = sub.add_parser("list", help="list recent jobs")
    ap_list.add_argument("--limit", type=int, default=50)
    ap_list.add_argument("--backend", default=None)
    ap_list.set_defaults(func=cmd_list)

    ap_status = sub.add_parser("status", help="show status for job ids")
    ap_status.add_argument("job_id", nargs="+")
    ap_status.set_defaults(func=cmd_status)

    ap_watch = sub.add_parser("watch", help="watch a job until terminal")
    ap_watch.add_argument("job_id")
    ap_watch.add_argument("--interval", type=float, default=2.0)
    ap_watch.set_defaults(func=cmd_watch)

    ap_cancel = sub.add_parser("cancel", help="cancel specific job ids")
    ap_cancel.add_argument("job_id", nargs="+")
    ap_cancel.set_defaults(func=cmd_cancel)

    ap_cp = sub.add_parser("cancel-pending", help="cancel queued/running for backend")
    ap_cp.add_argument("--backend", default=None)
    ap_cp.add_argument("--limit", type=int, default=200)
    ap_cp.set_defaults(func=cmd_cancel_pending)

    ap_latest = sub.add_parser("latest", help="print latest *_runlog.json")
    ap_latest.set_defaults(func=cmd_latest)

    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
