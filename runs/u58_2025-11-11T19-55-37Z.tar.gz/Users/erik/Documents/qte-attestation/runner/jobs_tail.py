#!/usr/bin/env python3
from qiskit_ibm_runtime import QiskitRuntimeService
svc = QiskitRuntimeService()
for j in svc.jobs(limit=20, descending=True):
    try: bname = j.backend().name
    except Exception: bname = "?"
    print(j.job_id(), str(j.status()), bname, getattr(j, "created_on", None))
