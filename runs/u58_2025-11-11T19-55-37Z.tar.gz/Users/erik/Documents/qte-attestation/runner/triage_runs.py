#!/usr/bin/env python3
import argparse, json, pathlib, math
from collections import Counter
from scipy.stats import beta

def cp_lower(s, n, alpha=0.05):
    # Clopper–Pearson lower bound
    if s == 0: return 0.0
    return beta.ppf(alpha/2, s, n - s + 1)

def cp_upper(s, n, alpha=0.05):
    # Clopper–Pearson upper bound
    if s == n: return 1.0
    return beta.ppf(1 - alpha/2, s + 1, n - s)

def hamming_weight(b): return b.count("1")

def succ_leq_r(counts, r):
    return sum(v for b, v in counts.items() if hamming_weight(b) <= r)

def load_pair(jsonl_path):
    recs = [json.loads(x) for x in open(jsonl_path)]
    keyed = next((r for r in recs if r.get("tag")=="keyed"), None)
    forg  = next((r for r in recs if r.get("tag")=="forger"), None)
    return keyed, forg

def top3(counts):
    items = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:3]
    return ", ".join(f"{b}:{c}" for b,c in items)

def main():
    ap = argparse.ArgumentParser(description="Triage recent attestation runs")
    ap.add_argument("--runs-dir", default="/Users/erik/Documents/qte-attestation/runs")
    ap.add_argument("--backend", default=None, help="Filter by backend name (e.g. ibm_torino)")
    ap.add_argument("--limit", type=int, default=20, help="Number of latest runs to show")
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--show-top", action="store_true")
    args = ap.parse_args()

    RUNS = pathlib.Path(args.runs_dir)
    # Pair runlog with *_submit_counts.jsonl by timestamp prefix
    runlogs = sorted(RUNS.glob("*_runlog.json"))[::-1]  # newest first
    rows = []
    matched = 0

    for logp in runlogs:
        try:
            meta = json.loads(open(logp).read())
        except Exception:
            continue
        if args.backend and meta.get("backend") != args.backend:
            continue
        ts = meta.get("ts","?")
        backend = meta.get("backend","?")
        shots = meta.get("shots","?")
        n = meta.get("n_qubits","?")
        job_id = meta.get("job_id","?")
        jsonl = RUNS/(logp.name.replace("_runlog.json","_submit_counts.jsonl"))
        if not jsonl.exists():
            continue

        keyed, forg = load_pair(jsonl)
        if not keyed or not forg:
            continue

        n = keyed["n_qubits"]; shots = keyed["shots"]
        # sweep radii to find smallest PASS
        r_pass = None; fpr = None; tpr = None; klo = None; fhi = None; ks0 = None; fs0 = None
        for r in range(n+1):
            ks = succ_leq_r(keyed["counts"], r)
            fs = succ_leq_r(forg["counts"], r)
            lo = cp_lower(ks, shots, args.alpha)
            hi = cp_upper(fs, shots, args.alpha)
            if lo >= 0.99 and hi <= 0.01:
                r_pass, fpr, tpr, klo, fhi = r, fs/shots, ks/shots, lo, hi
                break
            if r == 0:
                ks0, fs0 = ks, fs

        row = [
            ts, backend, job_id, n, shots,
            f"{ks0}/{shots}" if ks0 is not None else "-",   # keyed @ r=0
            f"{fs0}/{shots}" if fs0 is not None else "-",   # forger @ r=0
            (r_pass if r_pass is not None else "-"),
            (f"{tpr:.4f}" if tpr is not None else "-"),
            (f"{fpr:.4f}" if fpr is not None else "-"),
            (f"{klo:.5f}" if klo is not None else "-"),
            (f"{fhi:.5f}" if fhi is not None else "-"),
        ]
        if args.show_top:
            row += [top3(keyed["counts"]), top3(forg["counts"])]
        rows.append(row)
        matched += 1
        if matched >= args.limit:
            break

    if matched == 0:
        print("[triage] no runs matched (wrong backend filter or no *_submit_counts.jsonl yet).")
        return

    cols = ["ts","backend","job_id","n","shots","keyed@r0","forger@r0",
            "min_PASS_r","TPR","FPR","CP_lo(keyed)","CP_hi(forg)"]
    if args.show_top: cols += ["keyed_top3","forger_top3"]

    widths = [max(len(str(r[i])) for r in ([cols]+rows)) for i in range(len(cols))]
    print(" ".join(c.ljust(widths[i]) for i,c in enumerate(cols)))
    for r in rows:
        print(" ".join(str(v).ljust(widths[i]) for i,v in enumerate(r)))

if __name__ == "__main__":
    main()
