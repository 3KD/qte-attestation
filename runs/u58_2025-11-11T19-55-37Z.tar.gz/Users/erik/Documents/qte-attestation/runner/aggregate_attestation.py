#!/usr/bin/env python3
import argparse, json, pathlib, collections, random, shutil, subprocess, datetime, sys

def hw(bits:str)->int: return bits.count("1")
def succ_leq_r(counter, r:int)->int: return sum(v for b,v in counter.items() if hw(b)<=r)
def top3(counter): return ", ".join(f"{b}:{c}" for b,c in counter.most_common(3))

def auc(roc_pts):
    pts = sorted(roc_pts, key=lambda x: x[0])
    A = 0.0
    for i in range(len(pts)-1):
        x1,y1 = pts[i][0], pts[i][1]
        x2,y2 = pts[i+1][0], pts[i+1][1]
        A += (x2-x1)*(y1+y2)/2.0
    return A

def find_jsonls(base: pathlib.Path):
    return sorted(base.glob("*_submit_counts.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)

def load_pair(jsonl_path: pathlib.Path):
    try:
        lines = [json.loads(x) for x in open(jsonl_path)]
    except Exception:
        return None
    keyed  = next((r for r in lines if r.get("tag")=="keyed"), None)
    forger = next((r for r in lines if r.get("tag")=="forger"), None)
    if not keyed or not forger:
        return None
    K = collections.Counter({k:int(v) for k,v in keyed["counts"].items()})
    F = collections.Counter({k:int(v) for k,v in forger["counts"].items()})
    meta = {
        "backend": keyed.get("backend"),
        "shots": int(keyed.get("shots")),
        "n": int(keyed.get("n_qubits")),
        "path": str(jsonl_path),
    }
    return (K,F,meta)

def pick_pairs(base, backend, limit):
    pairs = []
    for p in find_jsonls(base):
        tup = load_pair(p)
        if not tup: continue
        K,F,meta = tup
        if backend and meta["backend"] != backend: continue
        pairs.append(tup)
        if len(pairs) >= limit: break
    return pairs

def sum_pairs(pairs):
    Kagg = collections.Counter(); Fagg = collections.Counter()
    shots = None; n = None
    for K,F,meta in pairs:
        Kagg.update(K); Fagg.update(F)
        shots = shots or meta["shots"]
        n = n or meta["n"]
    tot_shots = (shots or 0) * len(pairs)
    return Kagg, Fagg, (n or 0), tot_shots, (shots or 0)

def roc_from_counts(K, F, n, tot_shots):
    pts = []
    for r in range(n+1):
        ks = succ_leq_r(K, r)
        fs = succ_leq_r(F, r)
        TPR = ks / tot_shots if tot_shots else 0.0
        FPR = fs / tot_shots if tot_shots else 0.0
        pts.append((FPR, TPR, r, ks, fs))
    return pts

def bootstrap_auc_over_pairs(pairs, B=400, seed=1337):
    if not pairs: return (0.0, 0.0, 0.0)
    rnd = random.Random(seed)
    vals = []
    for _ in range(B):
        Ksum = collections.Counter(); Fsum = collections.Counter()
        n = None; shots = None
        for __ in range(len(pairs)):
            K,F,meta = pairs[rnd.randrange(len(pairs))]
            Ksum.update(K); Fsum.update(F)
            n = n or meta["n"]; shots = shots or meta["shots"]
        total = (shots or 0) * len(pairs)
        pts = roc_from_counts(Ksum, Fsum, (n or 0), total)
        vals.append(auc(pts))
    vals.sort()
    lo = vals[int(0.02*B)]; hi = vals[int(0.98*B)]
    mean = sum(vals)/B
    return (lo, hi, mean)

def qte_verify_bounds(ks:int, kt:int, fs:int, ft:int):
    exe = shutil.which("qte-attestation") or str(pathlib.Path(__file__).resolve().parent.parent/".venv"/"bin"/"qte-attestation")
    cmd = [exe,"verify","--keyed-succ",str(ks),"--keyed-trials",str(kt),
                  "--forg-succ",str(fs),"--forg-trials",str(ft),
                  "--alpha","0.05","--min-accept","0.99","--max-forge","0.01"]
    p = subprocess.run(cmd, capture_output=True, text=True)
    try:
        data = json.loads(p.stdout)
        return (float(data["keyed"]["cp_lower"]), float(data["forger"]["cp_upper"]), bool(data["PASS"]))
    except Exception:
        return (None, None, False)

def main():
    ap = argparse.ArgumentParser(description="Aggregate U58 attestation over recent JSONLs")
    ap.add_argument("--runs", default="/Users/erik/Documents/qte-attestation/runs")
    ap.add_argument("--backend", default="")
    ap.add_argument("--limit", type=int, default=10)
    ap.add_argument("--show-roc", dest="show_roc", action="store_true")
    args = ap.parse_args()

    runs = pathlib.Path(args.runs)
    pairs = pick_pairs(runs, args.backend, args.limit)
    if not pairs:
        print("[aggregate] no matching *_submit_counts.jsonl found."); sys.exit(1)

    latest_path = pairs[0][2]["path"]
    latest_ts = pathlib.Path(latest_path).name.split("_submit_counts.jsonl")[0]
    backend = pairs[0][2]["backend"]

    Kagg, Fagg, n, total_shots, shots_per_pair = sum_pairs(pairs)
    pts = roc_from_counts(Kagg, Fagg, n, total_shots)
    A = auc(pts)
    a_lo, a_hi, a_mean = bootstrap_auc_over_pairs(pairs)

    cand = [p for p in pts if p[0] <= 0.01]
    tpr_at_1pct = cand[-1][1] if cand else 0.0

    min_pass_r = None; cp_rows = []
    for FPR,TPR,r,ks,fs in pts:
        klo, fhi, ok = qte_verify_bounds(ks, total_shots, fs, total_shots)
        cp_rows.append((r, TPR, FPR, ks, fs, klo, fhi, ok))
        if ok and min_pass_r is None: min_pass_r = r

    print(f"\nAggregated U58 (backend={backend}, n={n}, shots_per_pair={shots_per_pair}, pairs={len(pairs)}, total_shots={total_shots})")
    print(f"AUC = {A:0.4f}   (bootstrap 95% CI: {a_lo:0.4f}–{a_hi:0.4f}, mean={a_mean:0.4f})")
    print(f"TPR@1%FPR = {tpr_at_1pct:0.4f}")
    print(f"min_PASS_r = {min_pass_r if min_pass_r is not None else '-'}")
    print(f"aggregate keyed top3:  {top3(Kagg)}")
    print(f"aggregate forger top3: {top3(Fagg)}")

    if args.show_roc:
        print("\nROC (r, TPR, FPR, keyed, forger, CP_lo(keyed), CP_hi(forg), PASS)")
        for r,TPR,FPR,ks,fs,klo,fhi,ok in cp_rows:
            klo_s = f"{klo:0.5f}" if klo is not None else "-"
            fhi_s = f"{fhi:0.5f}" if fhi is not None else "-"
            print(f"{r:>2}  {TPR:0.4f}  {FPR:0.4f}   {ks}/{total_shots}  {fs}/{total_shots}   {klo_s:<8} {fhi_s:<8} {'PASS' if ok else 'fail'}")

    out = {
        "ts": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H-%M-%SZ"),
        "backend": backend,
        "n_qubits": n,
        "shots_per_pair": shots_per_pair,
        "num_pairs": len(pairs),
        "total_shots": total_shots,
        "AUC": A,
        "AUC_CI_95": [a_lo, a_hi],
        "AUC_boot_mean": a_mean,
        "TPR_at_1pct_FPR": tpr_at_1pct,
        "min_PASS_r": min_pass_r,
        "aggregate_keyed_top3": top3(Kagg),
        "aggregate_forger_top3": top3(Fagg),
        "ROC": [{"r": r, "TPR": float(TPR), "FPR": float(FPR), "keyed_succ": int(ks), "forger_succ": int(fs)} for (FPR,TPR,r,ks,fs) in pts],
        "source_paths": [m["path"] for _,_,m in pairs],
    }
    out_path = runs / f"{out['ts']}_U58_attestation.json"
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\n[aggregate] wrote {out_path}")

if __name__ == "__main__": main()
