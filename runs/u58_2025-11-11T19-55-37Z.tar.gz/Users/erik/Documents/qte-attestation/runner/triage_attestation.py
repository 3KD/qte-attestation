#!/usr/bin/env python3
# Triage U58 attestation runs: summarize pass/fail per run, find minimal PASS radius.
# - Scans /Users/erik/Documents/qte-attestation/runs/*_runlog.json
# - If --rehydrate is set, calls runner/await_then_harvest.py to extract counts for missing runs
# - Computes CP 95% bounds and prints the smallest r with keyed_lo>=0.99 and forger_hi<=0.01
import argparse, json, pathlib, subprocess, sys
from collections import Counter, defaultdict

BASE = pathlib.Path("/Users/erik/Documents/qte-attestation")
RUNS = BASE / "runs"

def load_json(p):
    with open(p, "r") as f:
        return json.load(f)

def load_jsonl_counts(jsonl_path):
    keyed = forg = None
    shots = n = None
    try:
        with open(jsonl_path, "r") as f:
            for line in f:
                rec = json.loads(line)
                if rec.get("tag") == "keyed":
                    keyed = Counter(rec["counts"])
                    shots = rec["shots"]; n = rec["n_qubits"]
                elif rec.get("tag") == "forger":
                    forg = Counter(rec["counts"])
                    shots = rec["shots"]; n = rec["n_qubits"]
    except FileNotFoundError:
        return None
    return {"keyed": keyed, "forger": forg, "shots": shots, "n": n} if (keyed and forg) else None

# exact Clopper–Pearson using SciPy (present in your env per earlier logs)
def cp_bounds(k, n, alpha=0.05):
    try:
        from scipy.stats import beta
    except Exception as e:
        print("ERROR: SciPy not available; cannot compute Clopper–Pearson.", file=sys.stderr)
        sys.exit(2)
    lo = 0.0 if k == 0 else float(beta.ppf(alpha/2, k, n-k+1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alpha/2, k+1, n-k))
    return lo, hi

def succ_leq_r(counts: Counter, r: int) -> int:
    # counts keys are bitstrings like "01010101"
    s = 0
    for b, v in counts.items():
        if b.count("1") <= r:
            s += v
    return s

def decide_min_pass_radius(keyed, forg, shots, n, alpha=0.05):
    for r in range(0, n+1):
        ks = succ_leq_r(keyed, r)
        fs = succ_leq_r(forg,  r)
        klo, _ = cp_bounds(ks, shots, alpha)
        _, fhi = cp_bounds(fs, shots, alpha)
        if (klo >= 0.99) and (fhi <= 0.01):
            return r, ks, fs, klo, fhi
    return None, None, None, None, None

def maybe_rehydrate(runlog_path: pathlib.Path):
    """Call await_then_harvest.py to extract counts for this runlog."""
    script = BASE / "runner" / "await_then_harvest.py"
    if not script.exists():
        return False
    try:
        subprocess.run([str(script)], check=False, stdout=sys.stdout, stderr=sys.stderr)
        return True
    except Exception:
        return False

def human_top3(c: Counter, k=3):
    return ", ".join([f"{b}:{c[b]}" for b in sorted(c, key=c.get, reverse=True)[:k]])

def main():
    ap = argparse.ArgumentParser(description="Triage attestation runs and find minimal PASS radius.")
    ap.add_argument("--backend", help="Filter by backend name (e.g., ibm_torino)")
    ap.add_argument("--limit", type=int, default=50, help="Only analyze the last N runlogs")
    ap.add_argument("--rehydrate", action="store_true", help="Fetch counts for runs missing JSONL by calling await_then_harvest.py")
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--show-top", action="store_true", help="Show top-3 outcomes for keyed/forger")
    args = ap.parse_args()

    runlogs = sorted(RUNS.glob("*_runlog.json"))
    if not runlogs:
        print("No runlogs found in", RUNS); sys.exit(1)
    runlogs = runlogs[-args.limit:]

    rows = []
    pass_hist = Counter()
    missing = 0

    for rl in runlogs:
        meta = load_json(rl)
        backend = meta.get("backend")
        if args.backend and backend != args.backend:
            continue
        ts = meta.get("ts"); jid = meta.get("job_id"); shots = meta.get("shots"); n = meta.get("n_qubits")
        jsonl = rl.with_name(rl.name.replace("_runlog.json", "_submit_counts.jsonl"))
        bundle = load_jsonl_counts(jsonl)

        if bundle is None and args.rehydrate:
            maybe_rehydrate(rl)
            bundle = load_jsonl_counts(jsonl)

        if bundle is None:
            missing += 1
            rows.append([ts, backend, jid, shots or "-", n or "-", "MISSING", "-", "-", "-", "-", "-"])
            continue

        keyed, forg = bundle["keyed"], bundle["forger"]
        shots, n = bundle["shots"], bundle["n"]

        r_star, ks, fs, klo, fhi = decide_min_pass_radius(keyed, forg, shots, n, alpha=args.alpha)
        k0 = succ_leq_r(keyed, 0); f0 = succ_leq_r(forg, 0)
        status = f"PASS r={r_star}" if r_star is not None else "FAIL all r"
        if r_star is not None: pass_hist[r_star] += 1

        if args.show_top:
            kt = human_top3(keyed); ft = human_top3(forg)
        else:
            kt = ft = ""

        rows.append([ts, backend, jid, shots, n, status,
                     f"{k0}/{shots}", f"{f0}/{shots}",
                     (f"{ks}/{shots}" if ks is not None else "-"),
                     (f"{klo:.5f}" if klo is not None else "-"),
                     (f"{fhi:.5f}" if fhi is not None else "-"),
                     kt, ft])

    # Print table
    hdr = ["ts","backend","job_id","shots","n","status","k@r0","f@r0","k@r*","CP_lo(k)","CP_hi(f)"]
    if args.show_top: hdr += ["keyed_top3","forger_top3"]
    colw = [max(len(str(r[i])) for r in ([hdr]+rows)) for i in range(len(hdr))]
    print(" ".join(h.ljust(colw[i]) for i,h in enumerate(hdr)))
    for r in rows:
        r = r[:len(hdr)]
        print(" ".join(str(x).ljust(colw[i]) for i,x in enumerate(r)))

    # Summary
    if pass_hist:
        print("\nMinimal PASS radius distribution:")
        for r in sorted(pass_hist):
            print(f"  r={r}: {pass_hist[r]} run(s)")
    if missing:
        print(f"\nNote: {missing} run(s) missing counts. Re-run with --rehydrate to fetch.")
